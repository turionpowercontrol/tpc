#include "MSVC_Round.h"

int round (float value) {
	return (int)(floor(value+0.5));
}