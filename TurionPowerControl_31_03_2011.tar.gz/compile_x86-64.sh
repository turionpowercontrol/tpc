c++ -m64 TurionPowerControl.cpp cpuPrimitives.cpp Processor.cpp config.cpp scaler.cpp Griffin.cpp MSRObject.cpp PCIRegObject.cpp MSVC_Round.cpp -o ../bin/TurionPowerControl
