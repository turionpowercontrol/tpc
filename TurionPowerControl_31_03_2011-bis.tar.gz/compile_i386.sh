c++ -m32 -D_FILE_OFFSET_BITS=64 TurionPowerControl.cpp cpuPrimitives.cpp Processor.cpp config.cpp scaler.cpp Griffin.cpp K10Processor.cpp MSVC_Round.cpp -o ../bin/TurionPowerControl
