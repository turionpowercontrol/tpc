#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
	#define uint64_t unsigned long long int
	#include <windows.h>
	#include "OlsApi.h"
#endif

#ifdef __GNUC__
	#include "cpuPrimitives.h"
	#include <string.h>
#endif

#include "Processor.h"


PState::PState (DWORD ps) {
	if ((ps>=0) && (ps<=7))
		pstate=ps;
	else
	{
		printf ("PState.cpp: Wrong pstate %d, assuming default PState 0\n",ps);
		pstate=0;
	}
}

DWORD PState::getPState () {
	return pstate;
}

void PState::setPState (DWORD ps) {
	if ((ps>=0) && (ps<=7))
			pstate=ps;
		else
		{
			printf ("PState.cpp: Wrong pstate %d, assuming default PState 0\n",ps);
			pstate=0;
		}
}

/*void Processor::setCore (DWORD core) {

	if (!isValidCore) return;

	selectedCore=core;

}

void Processor::setNode (DWORD node) {

	if (!isValidNode) return;

	selectedNode=node;

}*/

PROCESSORMASK Processor::getMask (DWORD core, DWORD node) {

	return (PROCESSORMASK)1<<((node*processorCores)+core);

}

//Return true if core is in the range, else shows an error message and return false
bool Processor::isValidCore (DWORD core) {

	if (core>=0 && core<processorCores) return true; else {
		printf ("Wrong core. Allowed range: 0-%d\n", (processorCores-1));
		return false;
	}
}

//Return false if node is in the range, else shows an error message and return false
bool Processor::isValidNode (DWORD node) {

	if (node>=0 && node<processorNodes) return true; else {
		printf ("Wrong node. Allowed range: 0-%d\n", (processorNodes-1));
		return false;
	}
}

float Processor::convertVIDtoVcore (DWORD curVid) {
	return 0;
}

DWORD Processor::convertVcoretoVID (float vcore) {
	return 0;
}

DWORD Processor::convertFDtoFreq (DWORD curFid, DWORD curDid) {
	return 0;
}

void Processor::convertFreqtoFD(DWORD, int *, int *) {
	return;
}

DWORD Processor::extractVID (DWORD eaxMsr) {
	return (eaxMsr & 0xfe00) >> 9;
}

DWORD Processor::extractDID (DWORD eaxMsr) {
	return (eaxMsr & 0x1c0) >> 6;
}

DWORD Processor::extractFID (DWORD eaxMsr) {
	return (eaxMsr & 0x3f);
}

DWORD Processor::extractIDDValue (DWORD edxMsr) {
	return (edxMsr & 0xff);
}

DWORD Processor::extractIDD (DWORD edxMsr) {
	return (edxMsr & 0x300) >>8;
}

DWORD Processor::storeVID (DWORD eaxMsr,DWORD VID) {
	return (eaxMsr & 0xFFFF01FF) + (VID<<9);
}

DWORD Processor::storeDID (DWORD eaxMsr,DWORD DID) {
	return (eaxMsr & 0xFFFFFE3F) + (DID<<6);
}

DWORD Processor::storeFID (DWORD eaxMsr,DWORD FID) {
	return  eaxMsr=(eaxMsr & 0xFFFFFFC0) + (FID);
}

void Processor::setProcessorStrId (const char *strId) {
	strcpy_s (processorStrId,strId);
}

void Processor::setPowerStates (DWORD pstates) {
	powerStates=pstates;
}

void Processor::setProcessorCores (DWORD pcores) {
	processorCores=pcores;
}

void Processor::setProcessorIdentifier (DWORD pId) {
	processorIdentifier=pId;
}

void Processor::setProcessorNodes (DWORD nodes) {
	processorNodes=nodes;
}

DWORD Processor::HTLinkToFreq (DWORD reg) {

	switch (reg) {
	case 0:
		return 200;
	case 2:
		return 400;
	case 4:
		return 600;
	case 5:
		return 800;
	case 6:
		return 1000;
	case 7:
		return 1200;
	case 8:
		return 1400;
	case 9:
		return 1600;
	case 10:
		return 1800;
	case 11:
		return 2000;
	case 12:
		return 2200;
	case 13:
		return 2400;
	case 14:
		return 2600;
	default:
		return 0;
	}
}

void Processor::setSpecFamilyBase (int familyBase) {
	this->familyBase=familyBase;
}

void Processor::setSpecModel (int model) {
	this->model=model;
}

void Processor::setSpecStepping (int stepping) {
	this->stepping=stepping;
}

void Processor::setSpecFamilyExtended (int familyExtended) {
	this->familyExtended=familyExtended;
}

void Processor::setSpecModelExtended (int modelExtended) {
	this->modelExtended=modelExtended;
}

void Processor::setSpecBrandId (int brandId) {
	this->brandId=brandId;
}

void Processor::setSpecProcessorModel (int processorModel) {
	this->processorModel=processorModel;
}

void Processor::setSpecString1 (int string1) {
	this->string1=string1;
}

void Processor::setSpecString2 (int string2) {
	this->string2=string2;
}

void Processor::setSpecPkgType (int pkgType) {
	this->pkgType=pkgType;
}

int Processor::getSpecFamilyBase () {
	return this->familyBase;
}

int Processor::getSpecModel () {
	return this->model;
}

int Processor::getSpecStepping () {
	return this->stepping;
}

int Processor::getSpecFamilyExtended () {
	return this->familyExtended;
}

int Processor::getSpecModelExtended () {
	return this->modelExtended;
}

int Processor::getSpecBrandId () {
	return this->brandId;
}

int Processor::getSpecProcessorModel () {
	return this->processorModel;
}

int Processor::getSpecString1 () {
	return this->string1;
}

int Processor::getSpecString2 () {
	return this->string2;
}

int Processor::getSpecPkgType () {
	return this->pkgType;
}

/*** Following methods are likely to be overloaded/overridden inside each module ***/

/* setVID */
void Processor::setVID(PState ps, DWORD vid, DWORD core, DWORD node) {
	printf ("Processor::setVID(core,node)\n");
	return;
}

void Processor::setVID(PState ps, DWORD vid, DWORD core) {
	printf ("Processor::setVID(core)\n");
	return;
}

void Processor::setVID(PState ps, DWORD vid) {
	printf ("Processor::setVID()\n");
	return;
}

/* setFID */

void Processor::setFID(PState ps, DWORD fid, DWORD core, DWORD node) {
	return;
}

void Processor::setFID(PState ps, DWORD fid, DWORD core) {
	return;
}

void Processor::setFID(PState ps, DWORD fid) {
	return;
}

/* setDID */
void Processor::setDID(PState ps, DWORD did, DWORD core, DWORD node) {
	return;
}

void Processor::setDID(PState ps, DWORD did, DWORD core) {
	return;
}

void Processor::setDID(PState ps, DWORD did) {
	return;
}

/*
 * get* methods allows to gather specific vid/fid/did parameter.
 * Here we have just one complete variant (instead of three different
 * variant as set* methods have) with four parameters because
 * these methods return a single value. To avoid overlapping
 * and useless contradictions, and to make code more compact,
 * I prefer to make definitions of these methods as precise
 * as possible
 */

/* getVID */

DWORD Processor::getVID(PState ps, DWORD core, DWORD node) {
	return -1;
}

/* getFID */

DWORD Processor::getFID(PState ps, DWORD core, DWORD node) {
	return -1;
}

/* getDID */

DWORD Processor::getDID(PState ps, DWORD core, DWORD node) {
	return -1;
}


/* setFrequency */

void Processor::setFrequency(PState ps, DWORD frequency) {
	return;
}

void Processor::setFrequency(PState ps, DWORD frequency, DWORD core) {
	return;
}

void Processor::setFrequency(PState ps, DWORD frequency, DWORD core, DWORD node) {
	return;
}


/* setVCore */

void Processor::setVCore(PState ps, float vcore) {
	return;
}

void Processor::setVCore(PState ps, float vcore, DWORD core) {
	return;
}

void Processor::setVCore(PState ps, float vcore, DWORD core, DWORD node) {
	return;
}

/* getFrequency */

DWORD Processor::getFrequency(PState ps, DWORD core, DWORD node) {
	return -1;
}

/* getVCore */

float Processor::getVCore(PState ps, DWORD core, DWORD node) {
	return -1;
}

/* pStateEnable */
void Processor::pStateEnable(PState ps) {
	return;
}

void Processor::pStateEnable(PState ps, DWORD core) {
	return;
}


/* pStateDisable */
void Processor::pStateDisable(PState ps) {
	return;
}

void Processor::pStateDisable(PState ps, DWORD core) {
	return;
}

/* pStateEnabled (peeking) */
bool Processor::pStateEnabled(PState ps) {
	return false;
}

bool Processor::pStateEnabled(PState ps, DWORD core) {
	return false;
}

//Primitives to set maximum p-state
void Processor::setMaximumPState(PState ps) {
	printf("Unsupported processor feature\n");
	return;
}

PState Processor::getMaximumPState() {
	printf("Unsupported processor feature\n");
	return NULL;
}

/* setNBVid */
void Processor::setNBVid(DWORD vid) {
	printf("Unsupported processor feature\n");
	return;
}

void Processor::setNBVid(PState ps, DWORD vid) {
	printf("Unsupported processor feature\n");
	return;
}

/* setNBDid */
void Processor::setNBDid(PState ps, DWORD did) {
	printf("Unsupported processor feature\n");
	return;
}


/* getNBVid */
DWORD Processor::getNBVid() {
	printf("Unsupported processor feature\n");
	return -1;
}

DWORD Processor::getNBVid(PState ps, DWORD vid) {
	printf("Unsupported processor feature\n");
	return -1;
}

/* getNBDid */
DWORD Processor::getNBDid(PState ps) {
	printf("Unsupported processor feature\n");
	return -1;
}

/* setNBFid */
void Processor::setNBFid() {
	printf("Unsupported processor feature\n");
	return;
}

/* getMaxNBFrequency */
DWORD Processor::getMaxNBFrequency() {
	printf("Unsupported processor feature\n");
	return -1;
}

DWORD Processor::getMaxNBFrequencyByCore(DWORD core) {
	printf("Unsupported processor feature\n");
	return -1;
}


/* getNBFid */
DWORD Processor::getNBFid() {
	getNBFid (0);
}

DWORD Processor::getNBFid(DWORD node) {
	printf("Unsupported processor feature\n");
	return -1;
}

bool Processor::getPVIMode() {
	return false;
}

void Processor::forcePState(PState ps, DWORD core) {
	return;
}
bool Processor::getSMAF7Enabled() {
	return false;
}
DWORD Processor::c1eDID() {
	return -1;
}
DWORD Processor::minVID() {
	return -1;
}
DWORD Processor::maxVID() {
	return -1;
}
DWORD Processor::startupPState() {
	return -1;
}
DWORD Processor::maxCPUFrequency() {
	return 0;
} // 0 means that there

//DRAM timing register Low
DWORD Processor::getDRAMTimingLow(DWORD node,
		DWORD device, // 0 or 1
		DWORD *Tcl, DWORD *Trcd, DWORD *Trp, DWORD *Trtp, DWORD *Tras,
		DWORD *Trc, DWORD *Twr, DWORD *Trrd, DWORD *Tcwl, DWORD *T_mode) {
	return -1;
}

//DRAM timing register High
DWORD Processor::getDRAMTimingHigh(DWORD node, DWORD device, DWORD *TrwtWB,
		DWORD *TrwtTO, DWORD *Twtr, DWORD *Twrrd, DWORD *Twrwr, DWORD *Trdrd,
		DWORD *Tref, DWORD *Trfc0, DWORD *Trfc1, DWORD *Trfc2, DWORD *Trfc3) {
	return -1;
}

// method to modify DRAM timings -- Needs testing, only for DDR3 at the moment
DWORD Processor::setDRAMTiming(DWORD node,
		DWORD device, // 0 or 1
		DWORD Tcl, DWORD Trcd, DWORD Trp, DWORD Trtp, DWORD Tras, DWORD Trc,
		DWORD Twr, DWORD Trrd, DWORD Tcwl, DWORD T_mode) {
	return -1;
}

//Temperature registers
DWORD Processor::getTctlRegister(void) {
	return -1;
}
DWORD Processor::getTctlRegister(DWORD node) {
	return getTctlRegister();
}

DWORD Processor::getTctlMaxDiff(void) {
	return -1;
}
DWORD Processor::getTctlMaxDiff(DWORD node) {
	return getTctlMaxDiff();
}

//Voltage slamming time registers
DWORD Processor::getSlamTime(void) {
	return -1;
}
void Processor::setSlamTime(DWORD slamTime) {
	return;
}

DWORD Processor::getAltVidSlamTime(void) {
	return -1;
}
void Processor::setAltVidSlamTime(DWORD slamTime) {
	return;
}

//Voltage ramping time registers - Taken from Phenom Datasheets, not official on turions
DWORD Processor::getStepUpRampTime(void) {
	return -1;
}
DWORD Processor::getStepDownRampTime(void) {
	return -1;
}

void Processor::setStepUpRampTime(DWORD) {
	return;
}

void Processor::setStepDownRampTime(DWORD) {
	return;
}



//HTC Section
bool Processor::HTCisCapable() {
	return false;
}
bool Processor::HTCisCapableByNode(DWORD node) {
	return false;
}

bool Processor::HTCisEnabled() {
	return false;
}
bool Processor::HTCisEnabledByNode(DWORD node) {
	return false;
}

bool Processor::HTCisActive() {
	return false;
}
bool Processor::HTCisActiveByNode(DWORD node) {
	return false;
}

bool Processor::HTChasBeenActive() {
	return false;
}
bool Processor::HTChasBeenActiveByNode(DWORD node) {
	return false;
}

DWORD Processor::HTCTempLimit() {
	return -1;
}
DWORD Processor::HTCTempLimitByNode(DWORD node) {
	return -1;
}

bool Processor::HTCSlewControl() {
	return false;
}
bool Processor::HTCSlewControlByNode(DWORD node) {
	return false;
}

DWORD Processor::HTCHystTemp() {
	return -1;
}
DWORD Processor::HTCHystTempByNode(DWORD node) {
	return -1;
}

DWORD Processor::HTCPStateLimit() {
	return -1;
}
DWORD Processor::HTCPStateLimitByNode(DWORD node) {
	return -1;
}

bool Processor::HTCLocked() {
	return false;
}
bool Processor::HTCLockedByNode(DWORD node) {
	return false;
}

DWORD Processor::getAltVID() {
	return -1;
}
DWORD Processor::getAltVIDByNode(DWORD node) {
	return -1;
}

//HTC Section - Change status

void Processor::HTCEnable() {
	return;
}
void Processor::HTCEnableByNode(DWORD node) {
	return;
}

void Processor::HTCDisable() {
	return;
}
void Processor::HTCsetTempLimit(DWORD tempLimit) {
	return;
}
void Processor::HTCsetHystLimit(DWORD hystLimit) {
	return;
}
void Processor::setAltVid(DWORD altvid) {
	return;
}

//PSI_L bit

bool Processor::getPsiEnabled() {
	return false;
}
DWORD Processor::getPsiThreshold() {
	return -1;
}
void Processor::setPsiEnabled(bool toggle) {
	return;
}
void Processor::setPsiThreshold(DWORD threshold) {
	return;
}

//Hypertransport Section
DWORD Processor::getHTLinkSpeed() {
	return -1;
}
DWORD Processor::getHTLinkSpeedByNode(DWORD, DWORD, DWORD) {
	return -1;
}
DWORD Processor::getHTLinkWidthByNode(DWORD, DWORD, DWORD, DWORD*, DWORD *,
		bool *, bool *) {
	return -1;
}
DWORD Processor::getHTLinkDistributionTargetByNode(DWORD, DWORD, DWORD *,
		DWORD *) {
	return -1;
}

void Processor::setHTLinkSpeed(DWORD) {
	return;
}
void Processor::setHTLinkSpeedByNode(DWORD, DWORD, DWORD) {
	return;
}

void Processor::checkMode() {
	return;
}

//Various settings

bool Processor::getC1EStatus(DWORD core) {
	return false;
}
void Processor::setC1EStatus(DWORD core, bool toggle) {
	return;
}

//performance counters section

void Processor::perfCounterGetInfo() {
	return;
}
void Processor::perfCounterGetValue(int core, int perfCounter) {
	return;
}
void Processor::perfCounterMonitor(int core, int perfCounter) {
	return;
}
void Processor::perfMonitorCPUUsage() {
	return;
}

//Cpu Usage section
bool Processor::initUsageCounter(DWORD *) {
	return true;
}
DWORD Processor::getUsageCounter(DWORD *, DWORD) {
	return 0;
}
DWORD Processor::getUsageCounter(DWORD *, DWORD , int) {
	return 0;
}

//CPU Status
void Processor::getCurrentStatus(struct procStatus *, DWORD) {
	return;
}

//Misc
void Processor::forcePVIMode(bool toggle) {
	printf("Unsupported processor feature\n");
	return;
}
void Processor::forceSVIMode(bool toggle) {
	printf("Unsupported processor feature\n");
	return;
}
