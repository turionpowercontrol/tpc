#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
	#define uint64_t long long int
	#include <windows.h>
	#include "OlsApi.h"

#endif

#ifdef __GNUC__
	#include "cpuPrimitives.h"
	#include <string.h>
#endif

#include "Processor.h"
#include "Griffin.h"

//Griffin Class constructor
Griffin::Griffin () {

	DWORD eax,ebx,ecx,edx;

	//Check extended CpuID Information - CPUID Function 0000_0001 reg EAX
	if (Cpuid(0x1,&eax,&ebx,&ecx,&edx)!=TRUE) {
		printf ("Griffin::Griffin - Fatal error during querying for Cpuid(0x1) instruction.\n");
		return;
	}

	int familyBase = (eax & 0xf00) >> 8;
	int model = (eax & 0xf0) >> 4;
	int stepping = eax & 0xf;
	int familyExtended = ((eax & 0xff00000) >> 20)+familyBase;
	int modelExtended = ((eax & 0xf0000) >> 16)+model;

	//Check Brand ID and Package type - CPUID Function 8000_0001 reg EBX
	if (Cpuid(0x80000001,&eax,&ebx,&ecx,&edx)!=TRUE) {
		printf ("Griffin::Griffin - Fatal error during querying for Cpuid(0x80000001) instruction.\n");
		return;
	}

	int brandId=(ebx & 0xffff);
	int processorModel=(brandId >> 4) & 0x7f;
	int string1=(brandId >> 11) & 0xf;
	int string2=(brandId & 0xf);
	int pkgType=(ebx >> 28);

	//Sets processor Specs
	setSpecFamilyBase (familyBase);
	setSpecModel (model);
	setSpecStepping (stepping);
	setSpecFamilyExtended (familyExtended);
	setSpecModelExtended (modelExtended);
	setSpecBrandId (brandId);
	setSpecProcessorModel (processorModel);
	setSpecString1 (string1);
	setSpecString2 (string2);
	setSpecPkgType (pkgType);

	//Check how many physical cores are present - CPUID Function 8000_0008 reg ECX
	if (Cpuid(0x80000008,&eax,&ebx,&ecx,&edx)!=TRUE) {
		printf ("Griffin::Griffin - Fatal error during querying for Cpuid(0x80000008) instruction.\n");
		return;
	}

	int physicalCores=(ecx & 0xff) + 1;

	//Sets Physical cores number
	setProcessorCores (physicalCores);

	//Sets Physical number of processors
	setProcessorNodes (1);

	//Set Power states number
	setPowerStates (8);

	//Detects a Turion ZM processor
	if ((physicalCores==2) && (string1==0) && (pkgType==0x2)) {
		setProcessorIdentifier (TURION_ULTRA_ZM_FAMILY);
		setProcessorStrId ("Turion Ultra ZM Processor");
	}

	//Detects a Turion RM processor
	if ((physicalCores==2) && (string1==1) && (pkgType==0x2)) {
		setProcessorIdentifier (TURION_X2_RM_FAMILY);
		setProcessorStrId ("Turion X2 RM Processor");
	}

	//Detects a Turion QL processor
	if ((physicalCores==2) && (string1==2) && (pkgType==0x2)) {
		setProcessorIdentifier (ATHLON_X2_QL_FAMILY);
		setProcessorStrId ("Athlon X2 QL Processor");
	}

	//Detects a Sempron SI processor 
	if ((physicalCores==1) && (string1==0) && (pkgType==0x2)) {
		setProcessorIdentifier (SEMPRON_SI_FAMILY);
		setProcessorStrId ("Sempron SI Processor");
	}


}


/*
 * Static methods to allow external Main to detect current configuration status
 * without instantiating an object. This method that detects if the system
 * has a processor supported by this module
*/
bool Griffin::isProcessorSupported () {

	DWORD eax;
	DWORD ebx;
	DWORD ecx;
	DWORD edx;

	//Check base CpuID information
	if (Cpuid(0x0,&eax,&ebx,&ecx,&edx)!=TRUE) return false;
	
	//Checks if eax is 0x1, 0x5 or 0x6. It determines the largest CPUID function available
	//Family 11h returns eax=0x1
	if ((eax!=0x1)) return false;

	//Check for "AuthenticAMD" string
	if ((ebx!=0x68747541) || (ecx!=0x444D4163) || (edx!=0x69746E65)) return false;

	//Check extended CpuID Information - CPUID Function 0000_0001 reg EAX
	if (Cpuid(0x1,&eax,&ebx,&ecx,&edx)!=TRUE) return false;

	int familyBase = (eax & 0xf00) >> 8;
	int model = (eax & 0xf0) >> 4;
	int stepping = eax & 0xf;
	int familyExtended = ((eax & 0xff00000) >> 20)+familyBase;
	int modelExtended = ((eax & 0xf0000) >> 16)+model;

	//Check how many physical cores are present - CPUID Function 8000_0008 reg ECX
	if (Cpuid(0x80000008,&eax,&ebx,&ecx,&edx)!=TRUE) return false;

	int physicalCores=(ecx & 0xff) + 1;

	//Check Brand ID and Package type - CPUID Function 8000_0001 reg EBX
	if (Cpuid(0x80000001,&eax,&ebx,&ecx,&edx)!=TRUE) return false;

	int brandId=(ebx & 0xffff);
	int processorModel=(brandId >> 4) & 0x7f;
	int string1=(brandId >> 11) & 0xf;
	int string2=(brandId & 0xf);
	int pkgType=(ebx >> 28);

	if (familyExtended!=0x11) return false;
	
	//We will say that a processor is supported ONLY and if ONLY all parameters gathered
	//above are precisely as stated below. In any other case, we don't detect a valid processor
	if (familyExtended==0x11) {
		//Detects a Turion ZM processor
		if ((physicalCores==2) && (string1==0) && (pkgType==0x2))
			return true;

		//Detects a Turion RM processor
		if ((physicalCores==2) && (string1==1) && (pkgType==0x2))
			return true;

		//Detects a Turion QL processor
		if ((physicalCores==2) && (string1==2) && (pkgType==0x2))
			return true;

		//Detects a Sempron SI processor
		if ((physicalCores==1) && (string1==0) && (pkgType==0x2))
			return true;
	} 

	return false;

}

//Shows specific informations about current processor family
void Griffin::showFamilySpecs () {

	DWORD clock_ramp_hyst;
	DWORD clock_ramp_hyst_ns;
	DWORD psi_l_enable;
	DWORD psi_thres;
	DWORD vddGanged;
	DWORD pstateId;
	DWORD miscReg;
	int i,k;

	//Shows Northbridge VID, SMAF7 and C1E info only if we detect a family 11h processor.
	//family 10h processors have a different approach 
	printf ("Processor Northbridge VID: %d (%.3fv)\n",getNBVid(),convertVIDtoVcore(getNBVid()));
	printf ("\n");

	if (getSMAF7Enabled()==true)
		printf ("SMAF7 is enabled; processor is using ACPI SMAF7 tables\n");
	else
		printf ("SMAF7 is disabled; using LMM Configuration registers for power management\n");

	printf ("DID to apply when in C1E state: %d\n",c1eDID());
	
	printf ("\n");

	for (i=0;i<getProcessorCores();i++) {		
		if (getC1EStatus(0)==false)
			printf ("Core %d C1E CMP halt bit is disabled\n", i);
		else
			printf ("Core %d C1E CMP halt bit is enabled\n", i);
	}

	printf ("\nVoltage Regulator Slamming time register: %d\n",getSlamTime());

	printf ("Voltage Regulator AltVID Slamming time register: %d\n",getAltVidSlamTime());

	if (ReadPciConfigDwordEx (MISC_CONTROL_3,0xa0,&miscReg)!=TRUE) {
		printf ("Unable to read PCI Register\n");
		return;
	}

	//Shows Dual plane/Triple plane only on family 11h processors
	vddGanged=(miscReg >> 30)  & 0x1;
	if (vddGanged==0)
		printf ("Processor is operating in Triple Plane mode\n");
	else
		printf ("Processor is operating in Dual Plane mode\n");
				
	pstateId=(miscReg >> 16) & 0xfff;
		
	psi_l_enable=getPsiEnabled();
	psi_thres=getPsiThreshold();

	printf ("Processor is using Serial VID Interface\n");
		
	printf ("Processor PState Identifier: 0x%x\n", pstateId);
	if (psi_l_enable)
	{
		printf ("PSI_L bit enabled (improve VRM efficiency in low power)\n");
		printf ("PSI voltage threshold VID: %d (%.3fv)\n", psi_thres, convertVIDtoVcore(psi_thres));
	}
	else
		printf ("PSI_L bit not enabled\n");
		
	if (ReadPciConfigDwordEx (MISC_CONTROL_3,0xd4,&miscReg)!=TRUE) {
		printf ("Unable to read PCI Register\n");
		return;
	}
	
	//Shows Clock ramp hysteresis only on family 11h processors
	clock_ramp_hyst=(miscReg>>8) & 0xf;
	clock_ramp_hyst_ns=(clock_ramp_hyst+1)*320;
	
	printf ("Clock ramp hysteresis register: %d (%d ns)\n", clock_ramp_hyst, clock_ramp_hyst_ns);

}


//Miscellaneous function for some conversions

float Griffin::convertVIDtoVcore (DWORD curVid) {
	return (float)((124-curVid)*0.0125);
}

DWORD Griffin::convertVcoretoVID (float vcore) {
	return (DWORD)((1.55-vcore)/(float)0.0125);
}

DWORD Griffin::convertFDtoFreq (DWORD curFid, DWORD curDid) {
	return (100*(curFid+0x8))/(1<<curDid);
}

void Griffin::convertFreqtoFD (DWORD freq, int *oFid, int *oDid) {
	/*Needs to calculate the approximate frequency using FID and DID right
	combinations. Take in account that base frequency is always 200 Mhz
	(that is Hypertransport 1x link speed).

	For family 11h processor the right formula is:

		(100*(Fid+8))/(2^Did)

	Inverse formulas are:

		fid = (((2^Did) * freq) / 100) - 8

		did = log2 ((100 * (fid + 8))/f)

	The approach I choose here is to minimize DID and maximize FID,
	with respect to the fact that it can't go over the maximum FID.
	Note: Family 11h processors don't like very much changing FID
	between pstates, and often this results in system freezes.
	I still can't figure the reason.

	As you can see, part of the argument of the log of the DID is obtained
	dividing 100*(fid+8) with required frequency.
	Since our maximum FID determines also a maximum operating frequency
	we can calculate the argument doing MaximumFrequency/WantedFrequency

	this way we get the argument of the logarithm. Now we calculate
	the DID calculating the logarithm and then taking only the integer
	part of the result.

	FID then is calculated accordingly, using the inverse formula.

	*/

	float fid;
	float did;

	float argument;

	if (freq==0) return;

	if (maxCPUFrequency()!=0) {

		//Normally all family 11h processors have locked upper multiplier
		//so we can use the idea above to obtain did and fid
		argument=maxCPUFrequency()/(float)freq;

		did=(int)(log(argument)/log((float)2));

	} else {

		//If we got an unlocked multiplier on a Family 11h processor
		//(which is very very unlikely), we fix did=2 and then calculate
		//a valid fid. This is because we can give lower voltages to
		//higher DIDs.
		did=2;

	}

	fid=(((1<<(int)did)*freq)/100)-8;

	if (fid>31) fid=31;

	//printf ("\n\nFor frequency %d, FID is %f, DID %f\n", freq, fid, did);

	*oDid=(int)did;
	*oFid=(int)fid;

	return;

}

//-----------------------setVID-----------------------------
//Overloads abstract class setVID to allow per-core and per-node personalization
void Griffin::setVID (PState ps, DWORD vid, DWORD core, DWORD node) {
	DWORD eaxMsr,edxMsr;

	if (!isValidCore (core)) return;
	if (!isValidNode (node)) return;

	if ((vid<28) || (vid>127)) {
		printf ("Griffin.cpp: VID Allowed range 28-127\n");
		return;
	}

	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,getMask(core, node))!=TRUE) {
		printf ("Griffin.cpp: unable to read MSR\n");
		return;
	}

	eaxMsr=storeVID (eaxMsr,vid);
	WrmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),eaxMsr,edxMsr,getMask(core, node));
}

void Griffin::setVID (PState ps, DWORD vid, DWORD core) {

	int i;

	for (i=0;i<processorNodes;i++)
		setVID (ps, vid, core, i);

}

//Implements abstract Processor method to set vid for all cores
void Griffin::setVID (PState ps, DWORD vid) {
	int i,j;

	for (j=0;j<processorNodes;j++) {
		for (i=0;i<processorCores;i++)
			setVID (ps,vid,i,j);
	}


	return;
}

//-----------------------setFID-----------------------------
//Overloads abstract Processor method to allow per-core personalization
void Griffin::setFID (PState ps, DWORD fid, DWORD core, DWORD node) {

	DWORD eaxMsr,edxMsr;

	if (!isValidCore (core)) return;
	if (!isValidNode (node)) return;

	if ((fid<0) || (fid>31)) {
		printf ("Griffin.cpp: FID Allowed range 0-31\n");
		return;
	}

	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,getMask (core, node))!=TRUE) {
		printf ("Griffin.cpp: unable to read MSR\n");
		return;
	}

	eaxMsr=storeFID (eaxMsr,fid);
	WrmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),eaxMsr,edxMsr,getMask (core, node));
}

void Griffin::setFID (PState ps, DWORD fid, DWORD core) {

	int i;

	for (i=0;i<processorNodes;i++)
		setFID (ps, fid, core, i);


}

void Griffin::setFID (PState ps, DWORD fid) {
	int i,j;

	for (j=0;j<processorNodes;j++) {
		for (i=0;i<processorCores;i++)
			setFID (ps, fid, i, j);
	}

	return;
}

//-----------------------setDID-----------------------------
//Overloads abstract Processor method to allow per-core personalization
void Griffin::setDID (PState ps, DWORD did, DWORD core, DWORD node) {
	DWORD eaxMsr,edxMsr;

	if (!isValidNode (node)) return;
	if (!isValidCore (core)) return;

	if ((did<0) || (did>4)) {
		printf ("Griffin.cpp: DID Allowed range 0-3\n");
		return;
	}

	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,getMask(core, node))!=TRUE) {
		printf ("Griffin.cpp: unable to read MSR\n");
		return;
	}
	eaxMsr=storeDID (eaxMsr,did);
	WrmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),eaxMsr,edxMsr,getMask(core, node));
}

void Griffin::setDID (PState ps, DWORD did, DWORD core) {

	int i;

	for (i=0;i<processorNodes;i++)
		setDID (ps, did, core, i);


}

void Griffin::setDID (PState ps, DWORD did) {
	int i, j;

	for (j=0;j<processorNodes;j++) {
		for (i=0;i<processorCores;i++)
			setDID (ps, did, i, j);
	}

	return;
}

//-----------------------getVID-----------------------------

DWORD Griffin::getVID (PState ps, DWORD core, DWORD node) {
	DWORD eaxMsr,edxMsr;

	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,getMask (core, node))!=TRUE) {
		printf ("Unable to read MSR");
		return -1;
	}

	return extractVID (eaxMsr);
}

//-----------------------getFID-----------------------------

DWORD Griffin::getFID (PState ps, DWORD core, DWORD node) {
	DWORD eaxMsr,edxMsr;

	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,getMask (core, node))!=TRUE) {
		printf ("Unable to read MSR");
		return -1;
	}

	return extractFID (eaxMsr);
}

//-----------------------getDID-----------------------------

DWORD Griffin::getDID (PState ps, DWORD core, DWORD node) {
	DWORD eaxMsr,edxMsr;

	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,getMask (core, node))!=TRUE) {
		printf ("Unable to read MSR");
		return -1;
	}

	return extractDID (eaxMsr);
}

//-----------------------setFrequency-----------------------------

void Griffin::setFrequency (PState ps, DWORD freq, DWORD core, DWORD node) {

	int fid, did;

	convertFreqtoFD (freq, &fid, &did);

	setFID (ps, (DWORD)fid, core, node);
	setDID (ps, (DWORD)did, core, node);

	return;
}

void Griffin::setFrequency (PState ps, DWORD freq, DWORD core) {

	int fid, did;

	convertFreqtoFD (freq, &fid, &did);

	setFID (ps, (DWORD)fid, core);
	setDID (ps, (DWORD)did, core);

	return;
}


void Griffin::setFrequency (PState ps, DWORD freq) {

	int fid, did;

	convertFreqtoFD (freq, &fid, &did);

	setFID (ps, (DWORD)fid);
	setDID (ps, (DWORD)did);

	return;

}


//-----------------------setVCore-----------------------------

void Griffin::setVCore (PState ps, float vcore, DWORD core, DWORD node) {

	DWORD vid;
	
	vid=convertVcoretoVID (vcore);

	//Check if VID is below maxVID value set by the processor.
	//If it is, then there are no chances the processor will accept it and
	//we reply with an error
	if (vid<maxVID()) {
		printf ("Unable to set vcore: %0.3fv exceed maximum allowed vcore (%0.3fv)\n", vcore, convertVIDtoVcore(maxVID()));
		return;
	}

	//Again we che if VID is above minVID value set by processor.
	if (vid>minVID()) {
		printf ("Unable to set vcore: %0.3fv is below minimum allowed vcore (%0.3fv)\n", vcore, convertVIDtoVcore(minVID()));
		return;
	}


	setVID (ps,vid,core, node);

	return;

}


void Griffin::setVCore (PState ps, float vcore, DWORD core) {

	DWORD vid;
	
	vid=convertVcoretoVID (vcore);

	if (vid<maxVID()) {
		printf ("Unable to set vcore: %0.3fv exceed maximum allowed vcore (%0.3fv)\n", vcore, convertVIDtoVcore(maxVID()));
		return;
	}

	if (vid>minVID()) {
		printf ("Unable to set vcore: %0.3fv is below minimum allowed vcore (%0.3fv)\n", vcore, convertVIDtoVcore(minVID()));
		return;
	}

	setVID (ps,vid,core);

	return;

}

void Griffin::setVCore (PState ps, float vcore) {

	DWORD vid;

	vid=convertVcoretoVID (vcore);

	if (vid<maxVID()) {
		printf ("Unable to set vcore: %0.3fv exceed maximum allowed vcore (%0.3fv)\n", vcore, convertVIDtoVcore(maxVID()));
		return;
	}

	if (vid>minVID()) {
		printf ("Unable to set vcore: %0.3fv is below minimum allowed vcore (%0.3fv)\n", vcore, convertVIDtoVcore(minVID()));
		return;
	}

	setVID (ps,vid);

	return;

}


//-----------------------getFrequency-----------------------------

DWORD Griffin::getFrequency (PState ps, DWORD core, DWORD node) {
	DWORD eaxMsr,edxMsr;
	DWORD curFid, curDid;
	DWORD curFreq;

	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,getMask (core, node))!=TRUE) {
		printf ("Unable to read MSR");
		return -1;
	}

	curFid=extractFID (eaxMsr);
	curDid=extractDID (eaxMsr);

	curFreq=(100*(curFid+0x8))/(1<<curDid);

	return curFreq;
}

//-----------------------getVCore-----------------------------

float Griffin::getVCore (PState ps,DWORD core, DWORD node) {
	DWORD eaxMsr,edxMsr;
	DWORD curVid;
	float curVcore;

	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,getMask (core, node))!=TRUE) {
		printf ("Unable to read MSR");
		return -1;
	}

	curVid=extractVID (eaxMsr);
	
	curVcore=(float)((124-curVid)*0.0125);

	return curVcore;
}

//PStates enable/disable/peek
void Griffin::pStateDisable (PState ps, DWORD core) {

	DWORD eaxMsr,edxMsr;
	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core)!=TRUE) {
		printf ("Griffin.cpp: Unable to read MSR\n");
		return;
	}
	edxMsr=edxMsr & 0x7fffffff;
	WrmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),eaxMsr,edxMsr,(PROCESSORMASK)1<<core);

}

void Griffin::pStateDisable (PState ps) {

	int i;

	for (i=0;i<processorCores;i++)
		pStateDisable (ps, i);
	
}

void Griffin::pStateEnable (PState ps, DWORD core) {

	DWORD eaxMsr,edxMsr;
	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core)!=TRUE) {
		printf ("Griffin.cpp: Unable to read MSR\n");
		return;
	}
	edxMsr=edxMsr | 0x80000000;
	WrmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),eaxMsr,edxMsr,(PROCESSORMASK)1<<core);

}

void Griffin::pStateEnable (PState ps) {

	int i;

	for (i=0;i<processorCores;i++)
		pStateEnable (ps, i);

}

bool Griffin::pStateEnabled (PState ps, DWORD core) {

	DWORD eaxMsr,edxMsr;
	if (RdmsrPx (BASE_ZM_PSTATEMSR+ps.getPState(),&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core)!=TRUE) {
		printf ("Griffin.cpp: Unable to read MSR\n");
		return false;
	}
	edxMsr=edxMsr >> 31;

	if (edxMsr==0) return false; 
	return true;	

}

bool Griffin::pStateEnabled (PState ps) {
	return pStateEnabled (ps, 0);
}

void Griffin::setMaximumPState (PState ps) {
	DWORD miscReg;

	if (ReadPciConfigDwordEx (MISC_CONTROL_3,0xdc,&miscReg)!=TRUE) {
		printf ("Unable to read PCI Register\n");
		return;
	}

	miscReg=(miscReg & 0xfffff8ff) + (ps.getPState() << 8);
	WritePciConfigDwordEx (MISC_CONTROL_3,0xdc,miscReg);
}

PState Griffin::getMaximumPState () {
	DWORD miscReg;
	PState ps (0);

	if (ReadPciConfigDwordEx (MISC_CONTROL_3,0xdc,&miscReg)!=TRUE) {
		printf ("Unable to read PCI Register\n");
		return NULL;
	}

	miscReg=(miscReg & 0x700) >> 8;
	ps.setPState (miscReg);

	return ps;
}

void Griffin::setNBVid (DWORD nbvid) {

	DWORD miscReg;
	ReadPciConfigDwordEx (MISC_CONTROL_3,0xdc,&miscReg);

	miscReg=(miscReg & 0xfff80fff) + (nbvid<<12);
	WritePciConfigDwordEx (MISC_CONTROL_3,0xdc,miscReg);

	return;
}

void Griffin::forcePState (PState ps, DWORD core) {
	
	DWORD eaxMsr,edxMsr;

	eaxMsr=ps.getPState() & 0x7;
	edxMsr=0;

	WrmsrPx (BASE_PSTATE_CTRL_REG,eaxMsr,edxMsr,(PROCESSORMASK)1<<core);

}

DWORD Griffin::getNBVid (void) {
	DWORD miscReg;
	DWORD curnbvid;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xdc,&miscReg);

	curnbvid=(miscReg & 0x7f000)>>12;

	return curnbvid;
}

bool Griffin::getSMAF7Enabled () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xD4,&miscReg);

	return (bool)!((miscReg >>18) & 0x1);
}

DWORD Griffin::c1eDID () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x1EC,&miscReg);

	return (miscReg >>16) & 0x7;
}

DWORD Griffin::minVID () {
	DWORD eaxMsr,edxMsr;

	if (Rdmsr (COFVID_STATUS_REG,&eaxMsr,&edxMsr)!=TRUE) {
		printf ("Unable to read MSR");
		return -1;
	}

	return (edxMsr >> 10) & 0x7f;
}

DWORD Griffin::maxVID () {
	DWORD eaxMsr,edxMsr;

	if (Rdmsr (COFVID_STATUS_REG,&eaxMsr,&edxMsr)!=TRUE) {
		printf ("Unable to read MSR");
		return -1;
	}

	return (edxMsr >> 3) & 0x7f;
}

DWORD Griffin::startupPState () {
	DWORD eaxMsr,edxMsr;

	if (Rdmsr (COFVID_STATUS_REG,&eaxMsr,&edxMsr)!=TRUE) {
		printf ("Unable to read MSR");
		return -1;
	}

	return edxMsr & 0x7;
}

DWORD Griffin::maxCPUFrequency () {
	DWORD eaxMsr,edxMsr;

	if (Rdmsr (COFVID_STATUS_REG,&eaxMsr,&edxMsr)!=TRUE) {
		printf ("Unable to read MSR");
		return -1;
	}

	return (((edxMsr >> 17) & 0x1F)+8)*100;
}

//Temperature registers ------------------

DWORD Griffin::getTctlRegister (void) {
	DWORD miscReg;
	DWORD curtmp;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xa4,&miscReg);

	curtmp=(miscReg >> 21) >> 3;

	return curtmp;
}

DWORD Griffin::getTctlMaxDiff (void) {
	DWORD miscReg;
	DWORD maxDiff;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xa4,&miscReg);

	maxDiff=(miscReg >>5) & 0x3;

	return maxDiff;
}

//Voltage Slamming time
DWORD Griffin::getSlamTime (void) {
	DWORD miscReg;
	DWORD vsSlamTime;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xd8,&miscReg);

	vsSlamTime=miscReg & 0x7;

	return vsSlamTime;
}

void Griffin::setSlamTime (DWORD slmTime) {
	DWORD miscReg;

	if (slmTime<0 || slmTime >7) {
		printf ("Invalid Slam Time: must be between 0 and 7\n");
		return;
	}

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xd8,&miscReg);

	miscReg=(miscReg & 0xFFFFFFF8) + (slmTime);

	WritePciConfigDwordEx (MISC_CONTROL_3,0xd8,miscReg);
}

DWORD Griffin::getAltVidSlamTime (void) {
	DWORD miscReg;
	DWORD vsSlamTime;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xd8,&miscReg);

	vsSlamTime=(miscReg >> 4) & 0x7;
	
	return vsSlamTime;
}

void Griffin::setAltVidSlamTime (DWORD slmTime) {
	DWORD miscReg;

	if (slmTime<0 || slmTime >7) {
		printf ("Invalid AltVID Slam Time: must be between 0 and 7\n");
		return;
	}

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xd8,&miscReg);
	
	miscReg=(miscReg & 0xFFFFFF8F)+ (slmTime<<4);

	WritePciConfigDwordEx (MISC_CONTROL_3,0xd8,miscReg);

}


/***** Available only on Family 10h processors

//Voltage Ramping time
DWORD Griffin::getStepUpRampTime (void) {
	DWORD miscReg;
	DWORD vsRampTime;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xd4,&miscReg);

	//miscReg=(miscReg & 0xF0FFFFFF) + (0x3 << 24);

	vsRampTime=(miscReg >> 24) & 0xf;

	//WritePciConfigDwordEx (MISC_CONTROL_3,0xd4,miscReg);

	return vsRampTime;
}

DWORD Griffin::getStepDownRampTime (void) {
	DWORD miscReg;
	DWORD vsRampTime;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xd4,&miscReg);

	vsRampTime=(miscReg >> 20) & 0xf;

	return vsRampTime;
}

void Griffin::setStepUpRampTime (DWORD rmpTime) {
	DWORD miscReg;

	if (rmpTime<0 || rmpTime>0xf) {
		printf ("Invalid Ramp Time: value must be between 0 and 15\n");
		return;
	}

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xd4,&miscReg);

	miscReg=(miscReg & 0xF0FFFFFF) + (rmpTime << 24);

	WritePciConfigDwordEx (MISC_CONTROL_3,0xd4,miscReg);
}

void Griffin::setStepDownRampTime (DWORD rmpTime) {
	DWORD miscReg;

	if (rmpTime<0 || rmpTime>0xf) {
		printf ("Invalid Ramp Time: value must be between 0 and 15\n");
		return;
	}

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xd4,&miscReg);

	miscReg=(miscReg & 0xFF0FFFFF) + (rmpTime << 20);

	WritePciConfigDwordEx (MISC_CONTROL_3,0xd4,miscReg);
}*/


// AltVID - HTC Thermal features

bool Griffin::HTCisCapable () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xe8,&miscReg);

	return (bool)((miscReg >> 10) & 0x1);
}

bool Griffin::HTCisEnabled () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	return (bool)((miscReg) & 0x1);
}

bool Griffin::HTCisActive () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	return (bool)((miscReg >> 4) & 0x1);
}

bool Griffin::HTChasBeenActive () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	return (bool)((miscReg >> 5) & 0x1);
}


DWORD Griffin::HTCTempLimit () {
	DWORD miscReg;
	DWORD tempLimit;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	tempLimit=52+(((miscReg >> 16) & 0x7f)>>1);
	return tempLimit;
}

bool Griffin::HTCSlewControl () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	return (bool)((miscReg >> 23) & 0x1);
}

DWORD Griffin::HTCHystTemp () {
	DWORD miscReg;
	DWORD hystTemp;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	hystTemp=((miscReg >> 24) & 0xf)>>1;
	return hystTemp;
}

DWORD Griffin::HTCPStateLimit () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	return (miscReg >> 28) & 0x7;
}

bool Griffin::HTCLocked () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	return (bool)((miscReg >> 31) & 0x1);
}

void Griffin::HTCEnable () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	miscReg=miscReg | 0x1;

	WritePciConfigDwordEx (MISC_CONTROL_3,0x64,miscReg);
}

void Griffin::HTCDisable () {
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	miscReg=miscReg & 0xFFFFFFFE;

	WritePciConfigDwordEx (MISC_CONTROL_3,0x64,miscReg);
}

void Griffin::HTCsetTempLimit (DWORD tempLimit) {

	DWORD miscReg;

	if (tempLimit<52 || tempLimit>115) {
		printf ("HTCsetTempLimit: accepted range between 52 and 115\n");
		return;
	}

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	miscReg=(miscReg & 0xFF80FFFF) + ((tempLimit - 52)<<17); //Register is from bit 16 to 24, but value need to be multiplied by 2
	
	WritePciConfigDwordEx (MISC_CONTROL_3,0x64,miscReg);
}

void Griffin::HTCsetHystLimit (DWORD hystLimit) {

	DWORD miscReg;

	if (hystLimit<0 || hystLimit>7) {
		printf ("HTCsetHystLimit: accepted range between 0 and 7\n");
		return;
	}

	ReadPciConfigDwordEx (MISC_CONTROL_3,0x64,&miscReg);

	miscReg=(miscReg & 0xF0FFFFFF) + (hystLimit<<25);
	
	WritePciConfigDwordEx (MISC_CONTROL_3,0x64,miscReg);
}

DWORD Griffin::getAltVID () {

	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xDC,&miscReg);

	return (miscReg & 0x7f);
}

void Griffin::setAltVid (DWORD altVid) {

	DWORD miscReg;

	if ((altVid<28) || (altVid>127)) {
		printf ("setAltVID: VID Allowed range 28-127\n");
		return;
	}

	ReadPciConfigDwordEx (MISC_CONTROL_3,0xDC,&miscReg);

	miscReg=(miscReg & 0xFFFFFF80)+altVid;

	WritePciConfigDwordEx (MISC_CONTROL_3,0xDC,miscReg);

	return;

}
	
// Hypertransport Link

DWORD Griffin::getHTLinkSpeed (void) {
	
	DWORD miscReg;

	ReadPciConfigDwordEx (MISC_CONTROL_0,0x88,&miscReg);

	return ((miscReg >> 8) & 0xF);

}

void Griffin::setHTLinkSpeed (DWORD reg) {

	DWORD miscReg;
	
	if ((reg==1) || (reg==3) || (reg==15) || (reg<=0) || (reg>=16)) {
		printf ("setHTLinkSpeed: invalid HT Link registry value\n");
		return;
	}

	ReadPciConfigDwordEx (MISC_CONTROL_0,0x88,&miscReg);

	miscReg=miscReg & 0xFFFFF0FF;
	miscReg=miscReg + (reg<<8);

	WritePciConfigDwordEx (MISC_CONTROL_0,0x88,miscReg);

	return;

}

// CPU Usage module

//private funciton to set a Performance Counter with Idle Counter event
void Griffin::setPCtoIdleCounter (int core, int perfCounter) {
	
	if (perfCounter<0 || perfCounter>3) {
		printf ("Performance counter out of range (0-3)\n");
		return;
	}

	if (core<0 || core>processorCores-1) {
		printf ("Core Id is out of range (0-1)\n");
		return;
	}

	WrmsrPx (BASE_PESR_REG+perfCounter,IDLE_COUNTER_EAX,IDLE_COUNTER_EDX,(PROCESSORMASK)1<<core);

}

//Initializes CPU Usage counter - see the scalers
//Acceptes a pointer to an array of DWORDs, the array is as long as the number of cores the processor has
//Returns true if there are no slots to put the performance counter, while returns false on success.
bool Griffin::initUsageCounter (DWORD *perfReg) {

	DWORD coreId, perf_reg;
	DWORD enabled, event, usrmode, osmode;
	DWORD eaxMsr, edxMsr;
	
	//Finds an empty Performance Counter slot and puts the correct event in the slot.
	for (coreId=0; coreId<processorCores; coreId++) {
		
		perfReg[coreId]=-1;

		for (perf_reg=0x0;perf_reg<0x4;perf_reg++) {

			RdmsrPx (BASE_PESR_REG+perf_reg,&eaxMsr,&edxMsr,coreId+1);
			event=eaxMsr & 0xff;
			enabled=(eaxMsr >> 22) & 0x1;
			usrmode=(eaxMsr >> 16) & 0x1;
			osmode=(eaxMsr >>17) & 0x1;
		
			//Found an already activated performance slot with right event parameters
			if (event==0x76 && enabled==1 && usrmode==1 && osmode==1) {
				perfReg[coreId]=perf_reg;
				printf ("Core %d is using already set Performace Counter %d\n",coreId,perf_reg);
				break;
			}
	
			//Found an empty slot ready to be populated
			if (enabled==0) {
				setPCtoIdleCounter (coreId, perf_reg);
				perfReg[coreId]=perf_reg;
				printf ("Core %d is using newly set Performace Counter %d\n",coreId,perf_reg);
				break;
			}
		}

		//If we're unable to set a performance counter for a core, then it is impossible to continue
		//Else do a call to getUsageCounter to initialize its static variables
		if (perfReg[coreId]==-1)
			return true;
		else
			getUsageCounter (perfReg,coreId);
	}

	return false;
}

//Gives CPU Usage in 1/baseTop of the total for specified core
//CPU Usage is equally stretched over any period of time between two calls
//to the function. If baseTop is set to 100, then cpu usage is reported as
//percentage of the total
DWORD Griffin::getUsageCounter (DWORD *perfReg, DWORD core, int baseTop) {

	static uint64_t tsc[MAX_CORES],pTsc[MAX_CORES],counter[MAX_CORES],pcounter[MAX_CORES];
	DWORD eaxMsr,edxMsr;
	uint64_t diff;

	RdmsrPx (TIME_STAMP_COUNTER_REG,&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core);
	tsc[core]=((uint64_t)edxMsr<<32)+eaxMsr;
	
	RdmsrPx (BASE_PERC_REG+perfReg[core],&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core);
	counter[core]=((uint64_t)edxMsr<<32)+eaxMsr;

	diff=((counter[core]-pcounter[core])*baseTop)/(tsc[core]-pTsc[core]);
				
	pcounter[core]=counter[core];
	pTsc[core]=tsc[core];
	
	return (DWORD)diff;

}

//Overloads previous method to return a standard percentage of cpu usage.
DWORD Griffin::getUsageCounter (DWORD *perfReg, DWORD core) {

	return getUsageCounter (perfReg, core, 100);

}

bool Griffin::getPsiEnabled () {

	bool psi_l_enable;
	DWORD miscReg;

	if (ReadPciConfigDwordEx (MISC_CONTROL_3,0xa0,&miscReg)!=TRUE) {
		printf ("Unable to read PCI Register\n");
		return false;
	}
	
	psi_l_enable=(miscReg >> 7) & 0x1;
		
	return psi_l_enable;
	
}

DWORD Griffin::getPsiThreshold () {

	DWORD psi_thres, miscReg;

	if (ReadPciConfigDwordEx (MISC_CONTROL_3,0xa0,&miscReg)!=TRUE) {
		printf ("Unable to read PCI Register\n");
		return -1;
	}
	
	psi_thres=miscReg & 0x7f;
		
	return psi_thres;
	
}

void Griffin::setPsiEnabled (bool toggle) {

	DWORD newReg;
	DWORD miscReg;

	if (ReadPciConfigDwordEx (MISC_CONTROL_3,0xa0,&miscReg)!=TRUE) {
		printf ("Unable to read PCI Register\n");
		return;
	}
	
	newReg=(miscReg & 0xFFFFFF7F) | (toggle << 7);
		
	WritePciConfigDwordEx (MISC_CONTROL_3,0xa0,newReg);
	
	return;
	
}

void Griffin::setPsiThreshold (DWORD threshold) {

	DWORD newReg;
	DWORD miscReg;
	
	if (threshold>minVID() || threshold<maxVID()) {
		printf ("setPsiThreshold: value must be between %d and %d\n",minVID(), maxVID());
		return;
	}

	if (ReadPciConfigDwordEx (MISC_CONTROL_3,0xa0,&miscReg)!=TRUE) {
		printf ("Unable to read PCI Register\n");
		return;
	}
	
	newReg=(miscReg & 0xFFFFFF80) | threshold;
		
	WritePciConfigDwordEx (MISC_CONTROL_3,0xa0,newReg);
	
	return;
	
}

// Various settings

bool Griffin::getC1EStatus (DWORD core) {

	if (core<0 || core>1) {
		printf ("getC1EStatus: valid core values are 0-1\n");
		return false;
	}

	DWORD eaxMsr,edxMsr;
	if (RdmsrPx (CMPHALT_REG,&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core)!=TRUE) {
		printf ("Griffin.cpp: Unable to read MSR\n");
		return false;
	}
	
	return (eaxMsr>>28) & 0x1;
	
}

void Griffin::setC1EStatus (DWORD core, bool toggle) {

	if (core<0 || core>1) {
		printf ("getC1EStatus: valid core values are 0-1\n");
		return;
	}

	DWORD eaxMsr,edxMsr;
	if (RdmsrPx (CMPHALT_REG,&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core)!=TRUE) {
		printf ("Griffin.cpp: Unable to read MSR\n");
		return;
	}
	
	eaxMsr=(eaxMsr & 0xEFFFFFFF) | (toggle << 28);
	
	WrmsrPx (CMPHALT_REG,eaxMsr,edxMsr,(PROCESSORMASK)1<<core);
	
	return;
	
}

// Performance Counters

void Griffin::perfCounterGetInfo () {
	
	DWORD perf_reg;
	DWORD coreId;
	DWORD eaxMsr,edxMsr;
	int event, enabled, usrmode, osmode;

	for (coreId=0; coreId<processorCores; coreId++) {

		for (perf_reg=0;perf_reg<0x4;perf_reg++) {

			RdmsrPx (BASE_PESR_REG+perf_reg,&eaxMsr,&edxMsr,coreId+1);
			event=eaxMsr & 0xff;
			enabled=(eaxMsr >> 22) & 0x1;
			usrmode=(eaxMsr >> 16) & 0x1;
			osmode=(eaxMsr >>17) & 0x1;
		
			printf ("Core %d - Perf Counter %d: EAX:%x EDX:%x - Evt: 0x%x En: %d U: %d OS: %d\n",coreId,perf_reg,eaxMsr,edxMsr,event,enabled,usrmode,osmode);
		}

	}

}

void Griffin::perfCounterGetValue (int core, int perfCounter) {
	
	DWORD eaxMsr,edxMsr;
	uint64_t counter;

	if (perfCounter<0 || perfCounter>3) {
		printf ("Performance counter out of range (0-3)\n");
		return;
	}

	if (core<0 || core>processorCores-1) {
		printf ("Core Id is out of range (0-1)\n");
		return;
	}

	RdmsrPx (BASE_PERC_REG+perfCounter,&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core);
	counter=((uint64_t)edxMsr<<32)+eaxMsr;

	printf ("\rEAX:%x EDX:%x - Counter: %lld\n",eaxMsr,edxMsr, counter);

}

void Griffin::perfMonitorCPUUsage () {

	DWORD coreId;
	DWORD *perfReg;

	DWORD cpu_usage;
//	DWORD eaxMsr, edxMsr;

	perfReg=(DWORD*)calloc (processorCores, sizeof (DWORD));
	
	if (initUsageCounter (perfReg)) {
		printf ("No available performance counter slots. Unable to run CPU Usage Monitoring\n");
		return;
	}

	while (1) {

		printf ("\rCPU Usage:");

		for (coreId=0x0;coreId<processorCores;coreId++) {

			cpu_usage=getUsageCounter (perfReg,coreId);

			printf (" core %d: %d%",coreId, cpu_usage);
		}
		
		Sleep (1000);
		
		printf ("\n");

	}

	//Never executed, since the always true loop before...
	free (perfReg);
}

void Griffin::perfCounterMonitor (int core, int perfCounter) {
	
	DWORD eaxMsr,edxMsr;
	uint64_t pcounter=0, counter=0, diff=0;
	uint64_t pTsc=0, tsc=1;

	printf ("Sizeof counter: %d", sizeof(counter));

	if (perfCounter<0 || perfCounter>3) {
		printf ("Performance counter out of range (0-3)\n");
		return;
	}

	if (core<0 || core>processorCores-1) {
		printf ("Core Id is out of range (0-1)\n");
		return;
	}

	printf ("\n");

	while (1) {

		RdmsrPx (TIME_STAMP_COUNTER_REG,&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core);
		tsc=((uint64_t)edxMsr<<32)+eaxMsr;
	
		RdmsrPx (BASE_PERC_REG+perfCounter,&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core);
		counter=((uint64_t)edxMsr<<32)+eaxMsr;

		diff=((counter-pcounter)*100)/(tsc-pTsc);
				
		printf ("\rEAX:%x EDX:%x - Counter: %llu - Ratio with TSC: %llu\n",eaxMsr,edxMsr, counter, diff);

		pcounter=counter;
		pTsc=tsc;
		
		Sleep (1000);
	}

}

void Griffin::getCurrentStatus (struct procStatus *pStatus, DWORD core) {

	DWORD eaxMsr, edxMsr;
	
	RdmsrPx (0xc0010071,&eaxMsr,&edxMsr,(PROCESSORMASK)1<<core);
	pStatus->pstate=(eaxMsr>>16) & 0x7;
	pStatus->vid=(eaxMsr>>9) & 0x7f;
	pStatus->fid=eaxMsr & 0x3f;
	pStatus->did=(eaxMsr >> 6) & 0x7;

return;

}


void Griffin::checkMode () {

	DWORD i,pstate,vid,fid,did;
	DWORD eaxMsr,edxMsr;
	DWORD timestamp;
	DWORD states[2][8];
	DWORD minTemp,maxTemp,temp;
	DWORD oTimeStamp;
	float curVcore;
	DWORD curFreq;
	DWORD maxPState;

	printf ("Monitoring...\n");
	
	maxPState=getMaximumPState().getPState();

	for (i=0;i<8;i++) {
		states[0][i]=0;
		states[1][i]=0;
	}

	minTemp=getTctlRegister();
	maxTemp=minTemp;
	oTimeStamp=GetTickCount ();

	while (1) {

		timestamp=GetTickCount ();

		printf (" \rTimestamp: %d - ",timestamp);
		for (i=0;i<processorCores;i++) {
			
			/*RdmsrPx (0xc0010063,&eaxMsr,&edxMsr,i+1);
			pstate=eaxMsr & 0x7;*/

			RdmsrPx (0xc0010071,&eaxMsr,&edxMsr,(PROCESSORMASK)1<<i);
			pstate=(eaxMsr>>16) & 0x7;
			vid=(eaxMsr>>9) & 0x7f;
			curVcore=(float)((124-vid)*0.0125);
			fid=eaxMsr & 0x3f;
			did=(eaxMsr >> 6) & 0x7;
			curFreq=(100*(fid+0x8))/(1<<did);

			states[i][pstate]++;

			printf ("c%d:ps%d vc%.3f fr%d - ",i,pstate,curVcore,curFreq);
			if (pstate>maxPState) 
				printf ("\n * Detected pstate %d on core %d\n",pstate,i);
		}


		temp=getTctlRegister();

		if (temp<minTemp) minTemp=temp;
		if (temp>maxTemp) maxTemp=temp;

		printf ("Tctl: %d",temp);

		if ((timestamp-oTimeStamp)>30000) {
			oTimeStamp=timestamp;
			printf ("\n\t0\t1\t2\t3\t4\t5\t6\t7\n");
			printf ("Core0:");
			for (i=0;i<8;i++)
				printf ("\t%d",states[0][i]);
			printf ("\nCore1:");
			for (i=0;i<8;i++)
				printf ("\t%d",states[1][i]);
			printf ("\n\nCurTctl:%d\t MinTctl:%d\t MaxTctl:%d\n",temp,minTemp,maxTemp);
		}
				

		Sleep (50);
	}

	return;
}
