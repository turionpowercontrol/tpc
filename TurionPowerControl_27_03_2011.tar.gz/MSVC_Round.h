#pragma once

#include <math.h>

int round (float);